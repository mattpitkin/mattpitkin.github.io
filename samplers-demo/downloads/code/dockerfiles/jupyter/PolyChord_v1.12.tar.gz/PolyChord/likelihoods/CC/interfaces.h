#ifndef INTERFACES_H
#define INTERFACES_H

extern "C" void polychord_c_interface( double (*)(double*,int,double*,int), void (*)(double*,double*,int), int, int, int, bool, int, double, int, double, bool, bool, bool, bool, bool, bool, bool, bool, bool, bool, int, int, int, char*, char*,int,double*,int*); 


#endif
